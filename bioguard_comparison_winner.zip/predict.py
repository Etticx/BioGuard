"""Use a notebook-exported BioGuard model package; no secret keys needed."""
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps
import tensorflow as tf


def prepare_image(path, size=224):
    with Image.open(path) as image:
        image = ImageOps.exif_transpose(image).convert("RGB")
        image = ImageOps.pad(image, (size, size), method=Image.Resampling.BILINEAR,
                             color=(0, 0, 0), centering=(0.5, 0.5))
        return np.asarray(image, dtype=np.float32)


class BioGuardPredictor:
    def __init__(self, package_dir):
        root = Path(package_dir)
        self.model = tf.keras.models.load_model(root / "bioguard.keras", compile=False)
        self.classes = json.loads((root / "class_names.json").read_text(encoding="utf-8"))
        self.policy = json.loads((root / "species_policy.json").read_text(encoding="utf-8"))
        self.config = json.loads((root / "preprocessing.json").read_text(encoding="utf-8"))
        self.selection = json.loads((root / "selection.json").read_text(encoding="utf-8"))

    def predict(self, image_path):
        pixels = prepare_image(image_path, self.config["image_size"])
        probabilities = self.model(pixels[None], training=False).numpy()[0]
        index = int(np.argmax(probabilities))
        confidence = float(probabilities[index])
        name = self.classes[index]
        threshold = self.selection["review_threshold"]
        uncertain = threshold is None or confidence < threshold
        return {"predicted_species": name, "confidence": confidence,
                "uncertain_identification": uncertain,
                "sdp_listed_invasive": self.policy[name]["sdp_invasive"],
                "ecological_review_required": True,
                "automatic_removal_authorized": False,
                "known_class_scope_only": True,
                "top_three": [{"species": self.classes[int(i)], "confidence": float(probabilities[i])}
                              for i in np.argsort(probabilities)[::-1][:3]]}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("package_dir")
    parser.add_argument("image")
    args = parser.parse_args()
    print(json.dumps(BioGuardPredictor(args.package_dir).predict(args.image), indent=2))
