BioGuard model package
Run type: full_training
Selected stage: fine_tuned
Final test accuracy: 0.7789
Final test macro F1: 0.7700
Test images: 380

Extract this entire package. With TensorFlow, NumPy and Pillow installed:
  python predict.py PATH_TO_PACKAGE PATH_TO_PHOTO
Use the environment versions to reproduce this run. TensorFlow CPU can be used
for Windows inference; Colab training uses a GPU-enabled TensorFlow runtime.
Input processing is EXIF -> RGB -> aspect-preserving 224x224 black padding.
Raw model input is float32 0-255. Normalisation is embedded; do not apply twice.
Model output order is class_names.json; never assume alphabetical order.

Scope: only the nine selected species, not an arbitrary invasive/non-invasive test.
Softmax confidence does not reliably reject unknown species.
All treatment/removal requires ecological approval. SDP-listed invasive status
is a policy reference, not an instruction to remove every specimen everywhere.
No SDP field pilot or verified operational/biodiversity impact is claimed.
Botanical labels have not been independently verified by an expert.
Manual image review complete: False

Data: iNaturalist Licensed Observation Images (curated subset, not iNat2021).
Preserve the per-image CC0/CC BY/CC BY-SA licenses and attribution in the manifest.
The split manifest contains source links and licenses; this package has no photo files.
SDP reference: 2025 Sustainability Report, printed pages 157-160.
Report: https://www.simedarbyproperty.com/sites/default/files/2026-04/SDP%20SR2025%20%28Mobile%29.pdf
Dataset: https://registry.opendata.aws/inaturalist-open-data/
Do not report smoke-test metrics as full-model training results.
