BioGuard three-model experiment
Run type: full_training
Architecture: EfficientNetV2B0
Selected by validation macro F1 only. Test results did not choose the winner.
Historical test accuracy: 0.8578947368421053
Historical test macro F1: 0.8550900312531763
The historical holdout was previously inspected; fresh field evaluation is still required.
Input: EXIF -> RGB -> aspect-preserving black padding, float32 0–255.
Normalisation is embedded. Preserve class_names.json order.
Nine supported species only. Confidence does not reliably reject unknown species.
Manual review unfinished; botanical labels not independently verified.
No automatic ecological treatment/removal is authorised.
Preserve per-image licences and attribution in split_manifest.jsonl.
